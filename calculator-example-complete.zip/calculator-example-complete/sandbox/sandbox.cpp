#include "antlr4-runtime.h"
#include "CalculatorLexer.h"
#include "CalculatorParser.h"
#include "CalcErrorHandler.h"
#include "SemanticVisitor.h"

int i = 1;