/**
 * @file PropertyManager.cpp
 * @author your name (you@domain.com)
 * @brief includes the header file that contains everything
 * @version 0.1
 * @date 2022-07-23
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "PropertyManager.h"